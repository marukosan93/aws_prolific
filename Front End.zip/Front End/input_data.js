input_data = '[{"name" : "HIT_profession", "type" : "Text"},\
               {"name" : "HIT_likes", "type" : "Text"},\
               {"name" : "HIT_shares", "type" : "Text"},\
               {"name" : "HIT_healthclaim", "type" : "Text"},\
               {"name" : "HIT_profilepic", "type" : "Image","url":"https://mturk-critical.s3.eu-central-1.amazonaws.com/"}]';
