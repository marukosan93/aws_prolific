      var json_res; //stores info on all scenarios in batch
      const studyname = sessionStorage.getItem("studyname")

      function setTextOrImage(id, newvalue,text_or_image,url) {
        var s = document.getElementById(id);
        if (text_or_image == "Text"){
          s.innerHTML = newvalue;}
        if (text_or_image == "Image"){
          s.src = url + newvalue;
        }
      }
      // define the function that calls SubmitAnswers Lambda function via API
      var callAPIsubmit = () => {
        // instantiate a headers object
        var myHeaders = new Headers();

        // add content type header to object
        myHeaders.append("Content-Type", "application/json");
        // using built in JSON utility package turn object to string and store in a variable
        var raw = JSON.stringify({
          "prolificId": prolificId,
          "answers": allAnswers,
          "studyname": studyname
        });

        // create a JSON object with parameters for API call and store in a variable
        var requestOptions = {
          method: 'POST',
          headers: myHeaders,
          body: raw,
          redirect: 'follow'
        };
        // make API call with parameters and use promises to get response
        fetch("https://ch2yrw4fg0.execute-api.eu-north-1.amazonaws.com/dev", requestOptions)
        .then(response => response.text())
        .then(result => JSON.parse(result).body)
        .then(string_result => {
           string_result = string_result.replaceAll("\"", ""); //Receives the completion code
            window.location.href = "https://app.prolific.co/submissions/complete?cc="+string_result; //Appends completion code to URL
            sessionStorage.clear();
          })
          .catch(error => console.log('error', error));
      }

      // define the function that calls readScenario Lambda Function via API
      var callAPIscenario = () => {
        // instantiate a headers object
        var myHeaders = new Headers();
        // add content type header to object
        myHeaders.append("Content-Type", "application/json");
        // using built in JSON utility package turn object to string and store in a variable
        var raw = JSON.stringify({
          "prolificId": prolificId,
          "studyname": studyname
        });
        // create a JSON object with parameters for API call and store in a variable
        var requestOptions = {
          method: 'POST',
          headers: myHeaders,
          body: raw,
          redirect: 'follow'
        };
        // make API call with parameters and use promises to get response
        fetch("https://s6lzp5l4rd.execute-api.eu-north-1.amazonaws.com/dev", requestOptions)
          .then(response => response.text())
          .then(result => JSON.parse(JSON.parse(result).body))
          .then(string_result => {
            json_res = string_result; //gets all the scenarios in one call
            loadScenario(); //loads the first scenario
          })
          .catch(error => console.log('error', error));

          alert("Do not exit the tab, otherwise it won't be possible to come back to your assignment")
      }

    var starttime = Date.now();
    var referrer = document.referrer; //Closes if not referred from other page
    if (!referrer) {
      window.location.href = "./tabwarning.html";
    }

    var sliderStatus = "false";
    //Keeps track whether the user has moved/clicked the slider
    function sliderMoved() {
      sliderStatus = "true";
    };

    //Saves answers in session storage
    var allAnswers;
    let allans = sessionStorage.getItem('allAnswers');
    if (allans != null) {
      allAnswers = allans;
    } else {
      allAnswers = "[";
      sessionStorage.setItem('allAnswers', allAnswers);
    }

    //Gets current scenario (0) and ID from storage
    var scenarioNumber = sessionStorage.getItem('scenarioNumber');
    var prolificId = sessionStorage.getItem('Prolific_ID');


    starttime = Date.now()
    var loader = document.getElementById("container-div");
    setTimeout(function() {
      loader.style.WebkitTransition = 'visibility .7s, opacity .7s';
      loader.style.opacity = '1';
      loader.style.visibility = 'visible';
    }, 700);

    function concat_ans_json(time){
      var concatenated = "";
      concatenated = concatenated.concat("{\"HIT_scenarioID\":\"" + json_res.scenarios[scenarioNumber].HIT_scenarioID)
      concatenated = concatenated.concat("\",\"Time\":\"" + String(time))
      var output = JSON.parse(output_data);
      for (let i = 0; i < output.length; i++) {
        var value =""
        if (output[i].type == "Text"){
          value = document.getElementById(output[i].name).innerHTML
        } else {
          value = document.getElementById(output[i].name).value
        }
        concatenated = concatenated.concat("\",\""+output[i].name+"\":\"" +value)
      }
      concatenated = concatenated.concat("\"}")
      return concatenated
    }

    function waitcursor(){
           document.body.style.cursor= "wait"
           var sbmttbtn = document.getElementById("submit-button");
           sbmttbtn.style.cursor = "wait";
    }

    function submitAllAnswers() {
      waitcursor();
      document.getElementById("submit-button").disabled = true;
      setTimeout(function() {
        document.getElementById("submit-button").disabled = false;
      }, 8000);
      if (sliderStatus == "false") {
        alert("Please choose a rating");
      } else {
        if (allAnswers.slice(-1) != ']') {
          var time_elapsed = Date.now() - starttime - 1400
          allAnswers = allAnswers.concat(concat_ans_json(time_elapsed)+"]")
        }
        sessionStorage.setItem('allAnswers', allAnswers);
        callAPIsubmit();
      }
    }

    function loadScenario() {
      starttime = Date.now()
      sessionStorage.setItem('scenarioNumber', scenarioNumber);
      var input = JSON.parse(input_data);
      for (let i = 0; i < input.length; i++) {
        setTextOrImage(input[i].name, json_res.scenarios[scenarioNumber][input[i].name],input[i].type,input[i].url);
      }
      var firstbtn = document.getElementById("next-button");
      var secondbtn = document.getElementById("submit-button");
      firstbtn.disabled = true;
      secondbtn.disabled = true;
      setTimeout(function() {
        firstbtn.disabled = false;
        secondbtn.disabled = false;
      }, 2000);
      if (scenarioNumber == json_res.scenarios.length - 1) {
        firstbtn.parentNode.replaceChild(secondbtn, firstbtn);
        secondbtn.style.visibility = 'visible';
      };
    };


    function loadNextScenario() {
      if (sliderStatus == "false") {
        alert("Please choose a rating")
      } else {
        var time_elapsed = Date.now() - starttime - 1400 //takes the fades into account
        allAnswers = allAnswers.concat(concat_ans_json(time_elapsed)+",")
        sessionStorage.setItem('allAnswers', allAnswers);

        document.getElementsByClassName("my-slider")[0].value = "4";
        scenarioNumber++;
        sliderStatus = "false"
        setTimeout(function() {
          loadScenario();
        }, 400);
        var loader = document.getElementById("container-div");
        loader.style.WebkitTransition = 'visibility .7s, opacity .7s';
        loader.style.opacity = '0';
        loader.style.visibility = 'hidden';
        setTimeout(function() {
          loader.style.WebkitTransition = 'visibility .7s, opacity .7s';
          loader.style.opacity = '1';
          loader.style.visibility = 'visible';
        }, 1100);
      };
    };
